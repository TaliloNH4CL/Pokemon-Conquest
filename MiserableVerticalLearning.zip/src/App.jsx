
import React from 'react';

function MyButton() {
  return (
    <body>
    <a href="https://www.nintendo.com/us/"> <img src="../img/Nintendo.png"></img></a>
    </body>
  );
}

export default MyButton;
