let jsonData = `[
  {"Name": "Eevee", "Url": "Pokemon/Eevee.html"},
  {"Name": "Vaporeon", "Url": "Pokemon/Vaporeon.html"},
  {"Name": "Jolteon", "Url": "Pokemon/Jolteon.html"},
  {"Name": "Espeon", "Url": "Pokemon/Espeon.html"},
  {"Name": "Flareon", "Url": "Pokemon/Flareon.html"},
  {"Name": "Umbreon", "Url": "Pokemon/Umbreon.html"},
  {"Name": "Leafeon", "Url": "Pokemon/Leafeon.html"},
  {"Name": "Glaceon", "Url": "Pokemon/Glaceon.html"},
  {"Name": "Ralts", "Url": "Pokemon/Ralts.html"},
  {"Name": "Kirlia", "Url": "Pokemon/Kirlia.html"},
  {"Name": "Hero/Heroine", "Url": "Hero/heroina.html"},
  {"Name": "Aya", "Url": "Hero/Aya.html"},
  {"Name": "Ginchiyo", "Url": "Hero/Ginchiyo.html"},
  {"Name": "Gracia", "Url": "Hero/Gracio.html"},
  {"Name": "Hanbei", "Url": "Hero/Hanbei.html"},
  {"Name": "Hanzo", "Url": "Hero/Hanzo.html"},
  {"Name": "Hideyoshi", "Url": "Hero/Hideyoshi.html"},
  {"Name": "Ieyasu", "Url": "Hero/Ieyasu.html"},
  {"Name": "Ina", "Url": "Hero/Ina.html"},
  {"Name": "Kai", "Url": "Hero/Kai.html"}
]`

let data = JSON.parse(jsonData)

function search_animal() {
  let input = document.getElementById('searchbar').value
  input = input.toLowerCase();
  let x = document.querySelector('#list-holder');
  x.innerHTML = ""

  for (i = 0; i < data.length; i++) {
    let obj = data[i];

    if (obj.Name.toLowerCase().includes(input)) {
      const elem = document.createElement("li")

      elem.innerHTML = `${obj.Name} - <a href="../${obj.Url}">To page</a>`

      x.appendChild(elem)
      
    }
    
  }
}