var myMusic= document.getElementById("music");

function play() {
$('#play').hide();
$('#pause').show();
  $('#pause').show();
myMusic.play();

}

function hiden(){
  $('#pause').hide();
}

function pause() {
  $('#play').show();
  $('#pause').hide();
myMusic.pause();

}

function Mainshow(){
  $('#mainInfo').show();
  $('#mainInfo').hidden(false)
}

function Mainhide(){
  $('#mainInfo').hide();
}

